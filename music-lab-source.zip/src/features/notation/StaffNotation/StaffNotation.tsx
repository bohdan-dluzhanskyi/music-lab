import { useEffect, useRef } from 'react';

import { Renderer, Stave, StaveNote, Voice, Formatter } from 'vexflow';

import './StaffNotation.scss';

export default function StaffNotation() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;

    if (!container) return;

    container.replaceChildren();

    const renderer = new Renderer(container, Renderer.Backends.SVG);

    renderer.resize(800, 180);

    const context = renderer.getContext();

    const stave = new Stave(20, 20, 760);

    stave.addClef('treble').addTimeSignature('4/4').setContext(context).draw();

    const notes = [
      new StaveNote({
        keys: ['a/4'],
        duration: 'q',
      }),

      new StaveNote({
        keys: ['c/5'],
        duration: 'q',
      }),

      new StaveNote({
        keys: ['e/5'],
        duration: 'q',
      }),

      new StaveNote({
        keys: ['a/5'],
        duration: 'q',
      }),
    ];

    const voice = new Voice({
      numBeats: 4,
      beatValue: 4,
    });

    voice.addTickables(notes);

    new Formatter().joinVoices([voice]).format([voice], 650);

    voice.draw(context, stave);

    return () => {
      container.replaceChildren();
    };
  }, []);

  return <div className="staff-notation" ref={containerRef} />;
}
